class Pessoa {
    
}

module.exports = Pessoa;