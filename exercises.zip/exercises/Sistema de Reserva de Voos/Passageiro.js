class Passageiro {
    constructor(nome, passaporte) {
        this.nome = nome;
        this.passaporte = passaporte;
        
    }
}

module.exports = Passageiro;