class Produto {
    constructor(nome, preco) {
        this.nome = nome;
        this.preco = preco;
        
    }
   
}

module.exports = Produto;